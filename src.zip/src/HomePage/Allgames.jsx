import React from 'react'

export default function Allgames() {
  return (
    <div>
      <button>today's games</button>
    </div>
  )
}
