import React from 'react'

export default function Rating() {
  return (
    <div>
      <a href=""><h3>-----------------</h3></a>
      <a href=""><h3>-----------------</h3></a>
      <a href=""><h3>-----------------</h3></a>
    </div>
  )
}
