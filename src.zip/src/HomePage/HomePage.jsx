import React from "react";
import "./homepage.css";

export default function HomePage() {
  return (
    <div>
      <nav className="nav_main">
          <div>
          <a href="#">rating</a>
          </div>
        <div className="">
          <h4>name</h4>
        </div>
        <div>
          <button>hmburger</button>
        </div>
      </nav>
    </div>
  );
}
